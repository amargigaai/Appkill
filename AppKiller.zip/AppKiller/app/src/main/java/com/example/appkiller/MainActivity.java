package com.example.appkiller;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private List<AppItem> allApps = new ArrayList<>();
    private List<AppItem> filteredApps = new ArrayList<>();
    private AppAdapter adapter;
    private PrefsManager prefsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefsManager = new PrefsManager(this);
        setupRecyclerView();
        setupSearch();
        setupButtons();
        checkAndRequestPermissions();
    }

    private void setupRecyclerView() {
        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AppAdapter(this, filteredApps, this::updateDashboard);
        rv.setAdapter(adapter);
    }

    private void setupSearch() {
        EditText search = findViewById(R.id.searchBox);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { filterApps(s.toString()); }
            public void afterTextChanged(Editable s) {}
        });
    }

    private void filterApps(String q) {
        filteredApps.clear();
        for (AppItem a : allApps)
            if (a.getAppName().toLowerCase().contains(q.toLowerCase()))
                filteredApps.add(a);
        adapter.notifyDataSetChanged();
    }

    private void setupButtons() {
        findViewById(R.id.saveBtn).setOnClickListener(v -> saveSettings());
        findViewById(R.id.startStopBtn).setOnClickListener(v -> toggleService());
    }

    private void saveSettings() {
        Map<String, Integer> limits = new java.util.HashMap<>();
        for (AppItem app : allApps)
            if (app.isSelected())
                limits.put(app.getPackageName(), app.getTimeLimitMinutes());

        if (limits.isEmpty()) {
            Toast.makeText(this, "Select at least one app first!", Toast.LENGTH_SHORT).show();
            return;
        }
        prefsManager.saveAppLimits(limits);
        prefsManager.resetAlerts();
        Toast.makeText(this, "✅ Saved! " + limits.size() + " app(s) monitored.", Toast.LENGTH_SHORT).show();
        updateDashboard();
    }

    private void toggleService() {
        Intent svc = new Intent(this, AppMonitorService.class);
        Button btn = findViewById(R.id.startStopBtn);
        TextView badge = findViewById(R.id.activeBadge);

        if (AppMonitorService.isRunning) {
            stopService(svc);
            btn.setText("▶ Start Monitoring");
            badge.setText("● INACTIVE");
            badge.setTextColor(Color.parseColor("#6B7280"));
            badge.setBackgroundResource(R.drawable.badge_inactive_bg);
        } else {
            if (prefsManager.loadAppLimits().isEmpty()) {
                Toast.makeText(this, "Save your app selections first!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc);
            else startService(svc);
            btn.setText("Stop Monitoring");
            badge.setText("● ACTIVE");
            badge.setTextColor(Color.parseColor("#22C55E"));
            badge.setBackgroundResource(R.drawable.badge_active_bg);
        }
    }

    private void updateDashboard() {
        // Count selected apps
        int count = 0;
        List<AppItem> selected = new ArrayList<>();
        for (AppItem a : allApps) {
            if (a.isSelected()) { count++; selected.add(a); }
        }

        TextView countView = findViewById(R.id.trackingCount);
        countView.setText(String.valueOf(count));

        // Update chips
        LinearLayout chipsContainer = findViewById(R.id.chipsContainer);
        View chipsScroll = findViewById(R.id.chipsScroll);
        chipsContainer.removeAllViews();

        if (count > 0) {
            chipsScroll.setVisibility(View.VISIBLE);
            for (AppItem app : selected) {
                TextView chip = new TextView(this);
                int h = app.getTimeLimitMinutes() / 60;
                int m = app.getTimeLimitMinutes() % 60;
                String time = h > 0 ? h + "h" + m + "m" : m + "m";
                chip.setText("● " + app.getAppName() + "  •  " + time + " usage");
                chip.setTextSize(12f);
                chip.setTextColor(Color.parseColor("#9CA3AF"));
                chip.setBackgroundResource(R.drawable.dashboard_chip_bg);
                chip.setPadding(dp(12), dp(6), dp(12), dp(6));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMarginEnd(dp(8));
                chip.setLayoutParams(lp);
                chipsContainer.addView(chip);
            }
        } else {
            chipsScroll.setVisibility(View.GONE);
        }
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }

    private void loadInstalledApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        Map<String, Integer> saved = prefsManager.loadAppLimits();
        allApps.clear();

        for (ApplicationInfo info : packages) {
            if (info.packageName.equals(getPackageName())) continue;

            // Show all apps that have a launcher icon (works on Samsung too)
            Intent launch = pm.getLaunchIntentForPackage(info.packageName);
            if (launch == null) continue;

            boolean isSystem = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            boolean isUpdated = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
            if (isSystem && !isUpdated) continue;

            AppItem item = new AppItem(
                    pm.getApplicationLabel(info).toString(),
                    info.packageName,
                    pm.getApplicationIcon(info));

            if (saved.containsKey(info.packageName)) {
                item.setSelected(true);
                item.setTimeLimitMinutes(saved.get(info.packageName));
            }
            allApps.add(item);
        }

        Collections.sort(allApps, (a, b) -> a.getAppName().compareToIgnoreCase(b.getAppName()));
        filteredApps.clear();
        filteredApps.addAll(allApps);
        adapter.notifyDataSetChanged();
        updateDashboard();
    }

    // ── Permission Handling ──────────────────────────────────────────────────

    private void checkAndRequestPermissions() {
        if (!hasUsageStatsPermission()) showUsageStatsDialog();
        else onAllPermissionsGranted();
    }

    private boolean hasUsageStatsPermission() {
        try {
            android.app.AppOpsManager ops = (android.app.AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(
                    android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
            return mode == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    private void showUsageStatsDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Permission Required")
                .setMessage("AppKiller needs 'Usage Access' to track how long you use apps.\n\nTap OK to grant it.")
                .setPositiveButton("Open Settings", (d, w) ->
                        startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)))
                .setNegativeButton("Exit", (d, w) -> finish())
                .setCancelable(false).show();
    }

    private void onAllPermissionsGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);

        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Overlay Permission")
                    .setMessage("Allow 'Display over other apps' to show the time-up screen.")
                    .setPositiveButton("Grant", (d, w) -> startActivity(new Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()))))
                    .setNegativeButton("Skip", null).show();
        }
        loadInstalledApps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasUsageStatsPermission()) {
            loadInstalledApps();
            // Sync button/badge with service state
            Button btn = findViewById(R.id.startStopBtn);
            TextView badge = findViewById(R.id.activeBadge);
            if (AppMonitorService.isRunning) {
                btn.setText("Stop Monitoring");
                badge.setText("● ACTIVE");
                badge.setTextColor(Color.parseColor("#22C55E"));
                badge.setBackgroundResource(R.drawable.badge_active_bg);
            } else {
                btn.setText("▶ Start Monitoring");
                badge.setText("● INACTIVE");
                badge.setTextColor(Color.parseColor("#6B7280"));
                badge.setBackgroundResource(R.drawable.badge_inactive_bg);
            }
        } else {
            showUsageStatsDialog();
        }
    }
}
