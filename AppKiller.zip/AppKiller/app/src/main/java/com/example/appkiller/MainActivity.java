package com.example.appkiller;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private List<AppItem> allApps = new ArrayList<>();
    private List<AppItem> filteredApps = new ArrayList<>();
    private AppAdapter adapter;
    private PrefsManager prefsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefsManager = new PrefsManager(this);

        setupRecyclerView();
        setupSearch();
        setupButtons();

        checkAndRequestPermissions();
    }

    private void setupRecyclerView() {
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AppAdapter(this, filteredApps);
        recyclerView.setAdapter(adapter);
    }

    private void setupSearch() {
        EditText searchBox = findViewById(R.id.searchBox);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterApps(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void filterApps(String query) {
        filteredApps.clear();
        for (AppItem app : allApps) {
            if (app.getAppName().toLowerCase().contains(query.toLowerCase())) {
                filteredApps.add(app);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void setupButtons() {
        Button saveBtn = findViewById(R.id.saveBtn);
        Button startStopBtn = findViewById(R.id.startStopBtn);

        saveBtn.setOnClickListener(v -> saveSettings());
        startStopBtn.setOnClickListener(v -> toggleService());
    }

    private void saveSettings() {
        Map<String, Integer> limits = new java.util.HashMap<>();
        for (AppItem app : allApps) {
            if (app.isSelected()) {
                limits.put(app.getPackageName(), app.getTimeLimitMinutes());
            }
        }
        if (limits.isEmpty()) {
            Toast.makeText(this, "Please select at least one app!", Toast.LENGTH_SHORT).show();
            return;
        }
        prefsManager.saveAppLimits(limits);
        prefsManager.resetAlerts();
        Toast.makeText(this, "✅ Settings saved! " + limits.size() + " app(s) monitored.", Toast.LENGTH_LONG).show();
        updateStatusText();
    }

    private void toggleService() {
        Intent serviceIntent = new Intent(this, AppMonitorService.class);
        Button startStopBtn = findViewById(R.id.startStopBtn);

        if (AppMonitorService.isRunning) {
            stopService(serviceIntent);
            startStopBtn.setText("▶ Start Monitoring");
            Toast.makeText(this, "Monitoring stopped.", Toast.LENGTH_SHORT).show();
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            startStopBtn.setText("⏹ Stop Monitoring");
            Toast.makeText(this, "Monitoring started! 🔍", Toast.LENGTH_SHORT).show();
        }
        updateStatusText();
    }

    private void updateStatusText() {
        TextView statusText = findViewById(R.id.statusText);
        Map<String, Integer> limits = prefsManager.loadAppLimits();
        if (limits.isEmpty()) {
            statusText.setText("No apps selected yet. Pick apps below and save.");
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append(AppMonitorService.isRunning ? "🟢 Monitoring Active\n" : "🔴 Monitoring Stopped\n");
            sb.append(limits.size()).append(" app(s) tracked:\n");
            for (Map.Entry<String, Integer> e : limits.entrySet()) {
                String name = e.getKey();
                try {
                    name = getPackageManager().getApplicationLabel(
                            getPackageManager().getApplicationInfo(e.getKey(), 0)).toString();
                } catch (Exception ignored) {}
                int h = e.getValue() / 60, m = e.getValue() % 60;
                sb.append("• ").append(name).append(" → ");
                if (h > 0) sb.append(h).append("h ");
                sb.append(m).append("m\n");
            }
            statusText.setText(sb.toString().trim());
        }

        Button startStopBtn = findViewById(R.id.startStopBtn);
        startStopBtn.setText(AppMonitorService.isRunning ? "⏹ Stop Monitoring" : "▶ Start Monitoring");
    }

    private void loadInstalledApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        Map<String, Integer> savedLimits = prefsManager.loadAppLimits();

        allApps.clear();
        for (ApplicationInfo info : packages) {
            // Only show user-installed apps (not system apps)
            if ((info.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                // Skip our own app
                if (info.packageName.equals(getPackageName())) continue;
                AppItem item = new AppItem(
                        pm.getApplicationLabel(info).toString(),
                        info.packageName,
                        pm.getApplicationIcon(info)
                );
                // Restore saved settings
                if (savedLimits.containsKey(info.packageName)) {
                    item.setSelected(true);
                    item.setTimeLimitMinutes(savedLimits.get(info.packageName));
                }
                allApps.add(item);
            }
        }

        // Sort alphabetically
        Collections.sort(allApps, (a, b) -> a.getAppName().compareToIgnoreCase(b.getAppName()));

        filteredApps.clear();
        filteredApps.addAll(allApps);
        adapter.notifyDataSetChanged();
    }

    // ─── Permission Handling ───────────────────────────────────────────────────

    private void checkAndRequestPermissions() {
        if (!hasUsageStatsPermission()) {
            showUsageStatsDialog();
        } else {
            onAllPermissionsGranted();
        }
    }

    private boolean hasUsageStatsPermission() {
        try {
            android.app.AppOpsManager appOps =
                    (android.app.AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = appOps.checkOpNoThrow(
                    android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
            return mode == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    private void showUsageStatsDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Permission Required")
                .setMessage("AppKiller needs 'Usage Access' permission to monitor how long you use apps.\n\nTap OK to grant it in Settings.")
                .setPositiveButton("Open Settings", (d, w) -> {
                    startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                })
                .setNegativeButton("Exit", (d, w) -> finish())
                .setCancelable(false)
                .show();
    }

    private void onAllPermissionsGranted() {
        // Request notification permission on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        // Request overlay permission
        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Overlay Permission")
                    .setMessage("To show a blocking screen when time is up, we need 'Display over other apps' permission.")
                    .setPositiveButton("Grant", (d, w) -> {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    })
                    .setNegativeButton("Skip", null)
                    .show();
        }
        loadInstalledApps();
        updateStatusText();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasUsageStatsPermission()) {
            loadInstalledApps();
            updateStatusText();
        } else {
            showUsageStatsDialog();
        }
    }
}
