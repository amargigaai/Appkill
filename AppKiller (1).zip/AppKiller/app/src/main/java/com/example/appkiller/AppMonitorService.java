package com.example.appkiller;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.core.app.NotificationCompat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AppMonitorService extends Service {

    public static boolean isRunning = false;

    private static final String CHANNEL_ID_PERSISTENT = "AppKillerService";
    private static final String CHANNEL_ID_ALERT = "AppKillerAlert";
    private static final int NOTIFICATION_ID_PERSISTENT = 1;
    private static final int NOTIFICATION_ID_ALERT = 2;

    // Poll interval: check every 30 seconds
    private static final long POLL_INTERVAL_MS = 30_000;

    private Handler handler;
    private Runnable monitorRunnable;
    private PrefsManager prefsManager;

    // Tracks total foreground time per package in the current session (ms)
    private final Map<String, Long> sessionUsageMap = new HashMap<>();
    // Tracks when the app last came to foreground
    private final Map<String, Long> foregroundStartMap = new HashMap<>();

    @Override
    public void onCreate() {
        super.onCreate();
        prefsManager = new PrefsManager(this);
        handler = new Handler(Looper.getMainLooper());
        createNotificationChannels();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        isRunning = true;
        startForeground(NOTIFICATION_ID_PERSISTENT, buildPersistentNotification());

        checkDayRollover();
        startMonitoring();

        return START_STICKY; // Restart if killed by system
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        handler.removeCallbacks(monitorRunnable);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ─── Core Monitor Loop ─────────────────────────────────────────────────────

    private void startMonitoring() {
        monitorRunnable = new Runnable() {
            @Override
            public void run() {
                checkDayRollover();
                checkAppUsage();
                handler.postDelayed(this, POLL_INTERVAL_MS);
            }
        };
        handler.post(monitorRunnable);
    }

    private void checkAppUsage() {
        Map<String, Integer> limits = prefsManager.loadAppLimits();
        if (limits.isEmpty()) return;

        UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        long startOfDay = getStartOfDayMillis();

        // Query all usage events from start of day until now
        UsageEvents events = usm.queryEvents(startOfDay, now);
        UsageEvents.Event event = new UsageEvents.Event();

        // Reset session map and replay events to calculate foreground time
        Map<String, Long> foregroundTime = new HashMap<>();
        Map<String, Long> tempForegroundStart = new HashMap<>();

        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            String pkg = event.getPackageName();

            if (!limits.containsKey(pkg)) continue;

            if (event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                tempForegroundStart.put(pkg, event.getTimeStamp());
            } else if (event.getEventType() == UsageEvents.Event.MOVE_TO_BACKGROUND) {
                Long start = tempForegroundStart.get(pkg);
                if (start != null) {
                    long duration = event.getTimeStamp() - start;
                    foregroundTime.put(pkg, foregroundTime.getOrDefault(pkg, 0L) + duration);
                    tempForegroundStart.remove(pkg);
                }
            }
        }

        // Add ongoing foreground session (app currently open)
        for (Map.Entry<String, Long> entry : tempForegroundStart.entrySet()) {
            String pkg = entry.getKey();
            long duration = now - entry.getValue();
            foregroundTime.put(pkg, foregroundTime.getOrDefault(pkg, 0L) + duration);
        }

        // Check each monitored app
        for (Map.Entry<String, Integer> limitEntry : limits.entrySet()) {
            String pkg = limitEntry.getKey();
            long limitMs = limitEntry.getValue() * 60 * 1000L;
            long usedMs = foregroundTime.getOrDefault(pkg, 0L);

            if (usedMs >= limitMs && !prefsManager.isAlerted(pkg)) {
                triggerAlert(pkg, usedMs, limitMs);
            }
        }
    }

    // ─── Alert: Beep + Notification + Blocker Screen ─────────────────────────

    private void triggerAlert(String packageName, long usedMs, long limitMs) {
        prefsManager.markAlerted(packageName);

        // 1. Play beep sound
        playBeep();

        // 2. Show notification
        showAlertNotification(packageName, usedMs, limitMs);

        // 3. Launch blocker screen (overlay)
        launchBlocker(packageName, usedMs, limitMs);
    }

    private void playBeep() {
        try {
            ToneGenerator toneGen = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
            // Play 3 short beeps
            toneGen.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 300);
            handler.postDelayed(() -> toneGen.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 300), 400);
            handler.postDelayed(() -> {
                toneGen.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500);
                handler.postDelayed(toneGen::release, 700);
            }, 800);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlertNotification(String packageName, long usedMs, long limitMs) {
        String appName = getAppName(packageName);
        long usedMin = usedMs / 60000;
        long limitMin = limitMs / 60000;

        Intent intent = new Intent(this, BlockerActivity.class);
        intent.putExtra("package", packageName);
        intent.putExtra("appName", appName);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, packageName.hashCode(),
                intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID_ALERT)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("⏰ Time's up! " + appName)
                .setContentText("You've used " + appName + " for " + usedMin + " min (limit: " + limitMin + " min)")
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText("You've spent " + usedMin + " minutes on " + appName +
                                ". Your limit was " + limitMin + " minutes. Time to take a break! 🛑"))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
                .build();

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID_ALERT + packageName.hashCode(), notification);
    }

    private void launchBlocker(String packageName, long usedMs, long limitMs) {
        Intent intent = new Intent(this, BlockerActivity.class);
        intent.putExtra("package", packageName);
        intent.putExtra("appName", getAppName(packageName));
        intent.putExtra("usedMs", usedMs);
        intent.putExtra("limitMs", limitMs);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    // ─── Helpers ───────────────────────────────────────────────────────────────

    private String getAppName(String packageName) {
        try {
            return getPackageManager().getApplicationLabel(
                    getPackageManager().getApplicationInfo(packageName, 0)).toString();
        } catch (Exception e) {
            return packageName;
        }
    }

    private long getStartOfDayMillis() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    private void checkDayRollover() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String lastDate = prefsManager.loadLastDate();
        if (!today.equals(lastDate)) {
            // New day — reset alerts so limits apply fresh
            prefsManager.resetAlerts();
            prefsManager.saveLastDate(today);
        }
    }

    // ─── Notification Channels ─────────────────────────────────────────────────

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

            // Persistent (silent, low priority)
            NotificationChannel persistent = new NotificationChannel(
                    CHANNEL_ID_PERSISTENT, "AppKiller Monitor", NotificationManager.IMPORTANCE_LOW);
            persistent.setDescription("Background monitoring service");
            nm.createNotificationChannel(persistent);

            // Alert (high priority with sound)
            NotificationChannel alert = new NotificationChannel(
                    CHANNEL_ID_ALERT, "Time Limit Alerts", NotificationManager.IMPORTANCE_HIGH);
            alert.setDescription("Alerts when app time limit is reached");
            alert.enableVibration(true);
            nm.createNotificationChannel(alert);
        }
    }

    private Notification buildPersistentNotification() {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID_PERSISTENT)
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setContentTitle("AppKiller is active")
                .setContentText("Monitoring your app usage in background")
                .setContentIntent(pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }
}
