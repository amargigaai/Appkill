package com.example.appkiller;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AppAdapter extends RecyclerView.Adapter<AppAdapter.ViewHolder> {

    private final List<AppItem> apps;
    private final Context context;

    public AppAdapter(Context context, List<AppItem> apps) {
        this.context = context;
        this.apps = apps;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AppItem app = apps.get(position);

        holder.appName.setText(app.getAppName());
        holder.appIcon.setImageDrawable(app.getIcon());
        holder.checkBox.setChecked(app.isSelected());

        // Show time limit if selected
        if (app.isSelected()) {
            holder.timeLimit.setVisibility(View.VISIBLE);
            holder.timeLimit.setText(app.getTimeLimitMinutes() + " min");
        } else {
            holder.timeLimit.setVisibility(View.GONE);
        }

        // Toggle selection
        holder.checkBox.setOnClickListener(v -> {
            app.setSelected(holder.checkBox.isChecked());
            notifyItemChanged(position);
        });

        holder.itemView.setOnClickListener(v -> {
            app.setSelected(!app.isSelected());
            holder.checkBox.setChecked(app.isSelected());
            notifyItemChanged(position);
        });

        // Tap time limit to change it
        holder.timeLimit.setOnClickListener(v -> showTimePickerDialog(app, position));
    }

    private void showTimePickerDialog(AppItem app, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Set Time Limit for " + app.getAppName());

        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_time_picker, null);
        NumberPicker hourPicker = dialogView.findViewById(R.id.hourPicker);
        NumberPicker minutePicker = dialogView.findViewById(R.id.minutePicker);

        hourPicker.setMinValue(0);
        hourPicker.setMaxValue(23);
        minutePicker.setMinValue(1);
        minutePicker.setMaxValue(59);

        int totalMinutes = app.getTimeLimitMinutes();
        hourPicker.setValue(totalMinutes / 60);
        minutePicker.setValue(totalMinutes % 60 == 0 ? 30 : totalMinutes % 60);

        builder.setView(dialogView);
        builder.setPositiveButton("Set", (dialog, which) -> {
            int hours = hourPicker.getValue();
            int minutes = minutePicker.getValue();
            int total = hours * 60 + minutes;
            if (total == 0) total = 1;
            app.setTimeLimitMinutes(total);
            notifyItemChanged(position);
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    @Override
    public int getItemCount() {
        return apps.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView appIcon;
        TextView appName, timeLimit;
        CheckBox checkBox;

        ViewHolder(View itemView) {
            super(itemView);
            appIcon = itemView.findViewById(R.id.appIcon);
            appName = itemView.findViewById(R.id.appName);
            timeLimit = itemView.findViewById(R.id.timeLimit);
            checkBox = itemView.findViewById(R.id.checkBox);
        }
    }
}
