package com.example.appkiller;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class PrefsManager {

    private static final String PREFS_NAME = "AppKillerPrefs";
    private static final String KEY_APP_LIMITS = "app_limits";

    private final SharedPreferences prefs;

    public PrefsManager(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    /** Save a map of { packageName -> timeLimitMinutes } */
    public void saveAppLimits(Map<String, Integer> limits) {
        try {
            JSONArray array = new JSONArray();
            for (Map.Entry<String, Integer> entry : limits.entrySet()) {
                JSONObject obj = new JSONObject();
                obj.put("package", entry.getKey());
                obj.put("limit", entry.getValue());
                array.put(obj);
            }
            prefs.edit().putString(KEY_APP_LIMITS, array.toString()).apply();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /** Load saved app limits */
    public Map<String, Integer> loadAppLimits() {
        Map<String, Integer> limits = new HashMap<>();
        String json = prefs.getString(KEY_APP_LIMITS, null);
        if (json == null) return limits;
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                limits.put(obj.getString("package"), obj.getInt("limit"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return limits;
    }

    /** Track today's usage in memory-persistent prefs */
    public void saveUsageToday(String packageName, long usedMillis) {
        prefs.edit().putLong("usage_" + packageName, usedMillis).apply();
    }

    public long loadUsageToday(String packageName) {
        return prefs.getLong("usage_" + packageName, 0L);
    }

    public void resetAllUsageToday() {
        SharedPreferences.Editor editor = prefs.edit();
        Map<String, ?> all = prefs.getAll();
        for (String key : all.keySet()) {
            if (key.startsWith("usage_")) {
                editor.remove(key);
            }
        }
        editor.apply();
    }

    /** Track which apps have already been alerted today (to avoid repeated beeps) */
    public void markAlerted(String packageName) {
        prefs.edit().putBoolean("alerted_" + packageName, true).apply();
    }

    public boolean isAlerted(String packageName) {
        return prefs.getBoolean("alerted_" + packageName, false);
    }

    public void resetAlerts() {
        SharedPreferences.Editor editor = prefs.edit();
        Map<String, ?> all = prefs.getAll();
        for (String key : all.keySet()) {
            if (key.startsWith("alerted_")) {
                editor.remove(key);
            }
        }
        editor.apply();
    }

    /** Save last date to detect day change */
    public void saveLastDate(String date) {
        prefs.edit().putString("last_date", date).apply();
    }

    public String loadLastDate() {
        return prefs.getString("last_date", "");
    }
}
