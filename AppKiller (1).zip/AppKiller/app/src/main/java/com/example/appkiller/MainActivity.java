package com.example.appkiller;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private final List<AppItem> allApps      = new ArrayList<>();
    private final List<AppItem> filteredApps = new ArrayList<>();
    private AppAdapter    adapter;
    private PrefsManager  prefsManager;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefsManager = new PrefsManager(this);
        setupRecyclerView();
        setupSearch();
        setupButtons();
        checkAndRequestPermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasUsageStatsPermission()) {
            loadInstalledApps();
            syncServiceUI();
        } else {
            showUsageStatsDialog();
        }
    }

    // ── Setup ─────────────────────────────────────────────────────────────────

    private void setupRecyclerView() {
        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AppAdapter(this, filteredApps, this::updateDashboard);
        rv.setAdapter(adapter);
    }

    private void setupSearch() {
        EditText search = findViewById(R.id.searchBox);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { filterApps(s.toString()); }
            public void afterTextChanged(Editable s) {}
        });
    }

    private void setupButtons() {
        findViewById(R.id.saveBtn).setOnClickListener(v -> saveSettings());
        findViewById(R.id.startStopBtn).setOnClickListener(v -> toggleService());
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    private void filterApps(String q) {
        filteredApps.clear();
        for (AppItem a : allApps)
            if (a.getAppName().toLowerCase().contains(q.toLowerCase()))
                filteredApps.add(a);
        adapter.notifyDataSetChanged();
    }

    private void saveSettings() {
        Map<String, Integer> limits = new java.util.HashMap<>();
        for (AppItem app : allApps)
            if (app.isSelected())
                limits.put(app.getPackageName(), app.getTimeLimitMinutes());

        if (limits.isEmpty()) {
            Toast.makeText(this, "Select at least one app first!", Toast.LENGTH_SHORT).show();
            return;
        }
        prefsManager.saveAppLimits(limits);
        prefsManager.resetAlerts();
        Toast.makeText(this, "Saved! " + limits.size() + " app(s) monitored.", Toast.LENGTH_SHORT).show();
        updateDashboard();
    }

    private void toggleService() {
        Intent svc = new Intent(this, AppMonitorService.class);
        if (AppMonitorService.isRunning) {
            stopService(svc);
        } else {
            if (prefsManager.loadAppLimits().isEmpty()) {
                Toast.makeText(this, "Save your app selections first!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc);
            else startService(svc);
        }
        syncServiceUI();
    }

    private void syncServiceUI() {
        Button btn     = findViewById(R.id.startStopBtn);
        TextView badge = findViewById(R.id.activeBadge);
        if (AppMonitorService.isRunning) {
            btn.setText("Stop Monitoring");
            badge.setText("● ACTIVE");
            badge.setTextColor(Color.parseColor("#22C55E"));
            badge.setBackgroundResource(R.drawable.badge_active_bg);
        } else {
            btn.setText("Start Monitoring");
            badge.setText("● INACTIVE");
            badge.setTextColor(Color.parseColor("#6B7280"));
            badge.setBackgroundResource(R.drawable.badge_inactive_bg);
        }
    }

    // ── Dashboard ─────────────────────────────────────────────────────────────

    private void updateDashboard() {
        List<AppItem> selected = new ArrayList<>();
        for (AppItem a : allApps)
            if (a.isSelected()) selected.add(a);

        ((TextView) findViewById(R.id.trackingCount)).setText(String.valueOf(selected.size()));

        LinearLayout chips  = findViewById(R.id.chipsContainer);
        View         scroll = findViewById(R.id.chipsScroll);
        chips.removeAllViews();

        if (!selected.isEmpty()) {
            scroll.setVisibility(View.VISIBLE);
            for (AppItem app : selected) {
                TextView chip = new TextView(this);
                int h = app.getTimeLimitMinutes() / 60;
                int m = app.getTimeLimitMinutes() % 60;
                String time = h > 0 ? h + "h " + m + "m" : m + "m";
                chip.setText("● " + app.getAppName() + "  •  " + time);
                chip.setTextSize(12f);
                chip.setTextColor(Color.parseColor("#9CA3AF"));
                chip.setBackgroundResource(R.drawable.dashboard_chip_bg);
                chip.setPadding(dp(12), dp(6), dp(12), dp(6));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMarginEnd(dp(8));
                chip.setLayoutParams(lp);
                chips.addView(chip);
            }
        } else {
            scroll.setVisibility(View.GONE);
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ── App Loading (Universal - works on ALL Indian Android brands) ──────────

    private void loadInstalledApps() {
        PackageManager pm    = getPackageManager();
        Map<String, Integer> saved = prefsManager.loadAppLimits();
        allApps.clear();

        // ─────────────────────────────────────────────────────────────────────
        // USE queryIntentActivities with CATEGORY_LAUNCHER
        // This is the ONLY reliable method across all Indian phone brands:
        //
        //  • Samsung (One UI)       — marks Meta/Instagram as system apps
        //  • Xiaomi / Redmi (MIUI)  — bundles WhatsApp/Facebook as bloatware
        //  • Realme / OPPO          — pre-installs social apps with system flag
        //  • POCO / iQOO / Vivo     — same pattern
        //  • OnePlus (OxygenOS)     — mostly clean but same fix applies
        //  • Motorola / Nothing     — standard Android, works fine
        //  • Google Pixel           — standard Android, works fine
        //
        // getLaunchIntentForPackage() and FLAG_SYSTEM checks FAIL on these
        // brands because the apps carry system flags even though they are
        // user-facing. queryIntentActivities bypasses all flag checks and
        // simply asks: "what appears in the launcher?" — the ground truth.
        // ─────────────────────────────────────────────────────────────────────

        Intent launcherIntent = new Intent(Intent.ACTION_MAIN, null);
        launcherIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> resolveList =
                pm.queryIntentActivities(launcherIntent, PackageManager.GET_META_DATA);

        Set<String> seen = new HashSet<>();

        for (ResolveInfo ri : resolveList) {
            try {
                String pkg = ri.activityInfo.packageName;

                if (pkg.equals(getPackageName())) continue; // skip self
                if (seen.contains(pkg)) continue;           // skip duplicates
                seen.add(pkg);

                // Skip invisible framework internals that pollute the list
                if (isFrameworkInternal(pkg)) continue;

                String label = ri.loadLabel(pm).toString();
                android.graphics.drawable.Drawable icon = ri.loadIcon(pm);

                AppItem item = new AppItem(label, pkg, icon);
                if (saved.containsKey(pkg)) {
                    item.setSelected(true);
                    item.setTimeLimitMinutes(saved.get(pkg));
                }
                allApps.add(item);

            } catch (Exception ignored) {
                // Skip partially installed / unavailable apps
            }
        }

        Collections.sort(allApps, (a, b) ->
                a.getAppName().compareToIgnoreCase(b.getAppName()));

        filteredApps.clear();
        filteredApps.addAll(allApps);
        adapter.notifyDataSetChanged();
        updateDashboard();
    }

    /**
     * Returns true only for invisible Android framework processes that
     * should never appear in a user-facing app list. Social apps, games,
     * browsers and OEM apps are NOT filtered out.
     */
    private boolean isFrameworkInternal(String pkg) {
        String[] blocked = {
            "com.android.systemui",
            "com.android.inputmethod.latin",
            "com.android.providers.telephony",
            "com.android.providers.contacts",
            "com.android.providers.media",
            "com.android.providers.calendar",
            "com.android.providers.settings",
            "com.android.server.telecom",
            "com.google.android.gms",
            "com.google.android.gsf",
            "com.google.android.syncadapters",
            "com.qualcomm.qti",
            "com.mediatek.systemupdate",
        };
        for (String b : blocked)
            if (pkg.startsWith(b)) return true;
        return false;
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    private void checkAndRequestPermissions() {
        if (!hasUsageStatsPermission()) showUsageStatsDialog();
        else onAllPermissionsGranted();
    }

    private boolean hasUsageStatsPermission() {
        try {
            android.app.AppOpsManager ops =
                    (android.app.AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(
                    android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
            return mode == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    private void showUsageStatsDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Permission Required")
                .setMessage("AppKiller needs 'Usage Access' to track how long you use apps.\n\nTap OK to open Settings.")
                .setPositiveButton("Open Settings", (d, w) ->
                        startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)))
                .setNegativeButton("Exit", (d, w) -> finish())
                .setCancelable(false).show();
    }

    private void onAllPermissionsGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);

        if (!Settings.canDrawOverlays(this))
            new AlertDialog.Builder(this)
                    .setTitle("Overlay Permission")
                    .setMessage("Allow 'Display over other apps' to show the time-up screen.")
                    .setPositiveButton("Grant", (d, w) -> startActivity(new Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()))))
                    .setNegativeButton("Skip", null).show();

        loadInstalledApps();
    }
}
