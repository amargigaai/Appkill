package com.example.appkiller;

import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AppAdapter extends RecyclerView.Adapter<AppAdapter.ViewHolder> {

    private final List<AppItem> apps;
    private final Context context;
    private OnSelectionChangedListener listener;

    public interface OnSelectionChangedListener {
        void onSelectionChanged();
    }

    public AppAdapter(Context context, List<AppItem> apps, OnSelectionChangedListener listener) {
        this.context = context;
        this.apps = apps;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AppItem app = apps.get(position);

        holder.appName.setText(app.getAppName());
        holder.appIcon.setImageDrawable(app.getIcon());
        holder.checkBox.setChecked(app.isSelected());
        holder.appCategory.setText(getCategoryLabel(app));

        // Show time chip if selected
        if (app.isSelected()) {
            holder.timeLimit.setVisibility(View.VISIBLE);
            int h = app.getTimeLimitMinutes() / 60;
            int m = app.getTimeLimitMinutes() % 60;
            String label = h > 0 ? h + "h " + m + "m limit" : m + "min limit";
            holder.timeLimit.setText(label);
        } else {
            holder.timeLimit.setVisibility(View.GONE);
        }

        // Toggle on item click
        holder.itemView.setOnClickListener(v -> {
            app.setSelected(!app.isSelected());
            notifyItemChanged(position);
            if (listener != null) listener.onSelectionChanged();
        });

        holder.checkBox.setOnClickListener(v -> {
            app.setSelected(holder.checkBox.isChecked());
            notifyItemChanged(position);
            if (listener != null) listener.onSelectionChanged();
        });

        // Tap time chip to change limit
        holder.timeLimit.setOnClickListener(v -> showTimePicker(app, position));
    }

    private String getCategoryLabel(AppItem app) {
        String pkg = app.getPackageName().toLowerCase();
        if (pkg.contains("instagram") || pkg.contains("facebook") ||
            pkg.contains("twitter") || pkg.contains("snapchat") ||
            pkg.contains("tiktok") || pkg.contains("linkedin") ||
            pkg.contains("whatsapp") || pkg.contains("telegram")) return "Social";
        if (pkg.contains("youtube") || pkg.contains("netflix") ||
            pkg.contains("spotify") || pkg.contains("prime") ||
            pkg.contains("hotstar") || pkg.contains("jio")) return "Entertainment";
        if (pkg.contains("chrome") || pkg.contains("firefox") ||
            pkg.contains("browser") || pkg.contains("opera")) return "Browser";
        if (pkg.contains("game") || pkg.contains("pubg") ||
            pkg.contains("freefire") || pkg.contains("bgmi") ||
            pkg.contains("chess") || pkg.contains("ludo")) return "Gaming";
        if (pkg.contains("gmail") || pkg.contains("mail") ||
            pkg.contains("outlook") || pkg.contains("calendar")) return "Productivity";
        if (pkg.contains("samsung") || pkg.contains("android") ||
            pkg.contains("system") || pkg.contains("settings")) return "System";
        if (pkg.contains("camera") || pkg.contains("gallery") ||
            pkg.contains("photos") || pkg.contains("video")) return "Media";
        return "App";
    }

    private void showTimePicker(AppItem app, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Time limit for " + app.getAppName());

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_time_picker, null);
        NumberPicker hourPicker = view.findViewById(R.id.hourPicker);
        NumberPicker minutePicker = view.findViewById(R.id.minutePicker);

        hourPicker.setMinValue(0); hourPicker.setMaxValue(23);
        minutePicker.setMinValue(1); minutePicker.setMaxValue(59);

        int total = app.getTimeLimitMinutes();
        hourPicker.setValue(total / 60);
        minutePicker.setValue(total % 60 == 0 ? 30 : total % 60);

        builder.setView(view);
        builder.setPositiveButton("Set", (d, w) -> {
            int t = hourPicker.getValue() * 60 + minutePicker.getValue();
            app.setTimeLimitMinutes(Math.max(1, t));
            notifyItemChanged(position);
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    @Override
    public int getItemCount() { return apps.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView appIcon;
        TextView appName, timeLimit, appCategory;
        CheckBox checkBox;

        ViewHolder(View v) {
            super(v);
            appIcon    = v.findViewById(R.id.appIcon);
            appName    = v.findViewById(R.id.appName);
            timeLimit  = v.findViewById(R.id.timeLimit);
            appCategory = v.findViewById(R.id.appCategory);
            checkBox   = v.findViewById(R.id.checkBox);
        }
    }
}
