package com.example.appkiller;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class PrefsManager {

    private static final String PREFS = "AppKillerPrefs";
    private final SharedPreferences sp;

    public PrefsManager(Context ctx) {
        sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ── App Limits ────────────────────────────────────────────────────────────

    public void saveAppLimits(Map<String, Integer> limits) {
        try {
            JSONArray arr = new JSONArray();
            for (Map.Entry<String, Integer> e : limits.entrySet()) {
                JSONObject o = new JSONObject();
                o.put("package", e.getKey());
                o.put("limit", e.getValue());
                arr.put(o);
            }
            sp.edit().putString("app_limits", arr.toString()).apply();
        } catch (JSONException e) { e.printStackTrace(); }
    }

    public Map<String, Integer> loadAppLimits() {
        Map<String, Integer> out = new HashMap<>();
        String json = sp.getString("app_limits", null);
        if (json == null) return out;
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.put(o.getString("package"), o.getInt("limit"));
            }
        } catch (JSONException e) { e.printStackTrace(); }
        return out;
    }

    // ── Alert State ───────────────────────────────────────────────────────────

    /** Mark this package as having been alerted today */
    public void markAlerted(String pkg) {
        sp.edit().putBoolean("alerted_" + pkg, true).apply();
    }

    public boolean isAlerted(String pkg) {
        return sp.getBoolean("alerted_" + pkg, false);
    }

    /**
     * How many times has this app been alerted today?
     * 0 = first time → play sound_first (fahhhhh)
     * 1+ = subsequent → play sound_second (Modi ji bkl)
     */
    public int getAlertCount(String pkg) {
        return sp.getInt("alert_count_" + pkg, 0);
    }

    public void incrementAlertCount(String pkg) {
        int current = getAlertCount(pkg);
        sp.edit().putInt("alert_count_" + pkg, current + 1).apply();
    }

    /** Reset all alerts (called on day rollover or after save) */
    public void resetAlerts() {
        SharedPreferences.Editor ed = sp.edit();
        for (String key : sp.getAll().keySet()) {
            if (key.startsWith("alerted_") || key.startsWith("alert_count_"))
                ed.remove(key);
        }
        ed.apply();
    }

    // ── Date Tracking ─────────────────────────────────────────────────────────

    public void saveLastDate(String date) { sp.edit().putString("last_date", date).apply(); }
    public String loadLastDate()          { return sp.getString("last_date", ""); }
}
