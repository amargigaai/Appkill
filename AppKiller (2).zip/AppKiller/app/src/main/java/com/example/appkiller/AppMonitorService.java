package com.example.appkiller;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.core.app.NotificationCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AppMonitorService extends Service {

    public static boolean isRunning = false;

    private static final String CHANNEL_PERSISTENT = "AppKillerService";
    private static final String CHANNEL_ALERT      = "AppKillerAlert";
    private static final int    NOTIF_PERSISTENT   = 1;
    private static final int    NOTIF_ALERT_BASE   = 100;

    private static final long POLL_MS = 30_000; // check every 30 seconds

    private Handler handler;
    private Runnable monitorRunnable;
    private PrefsManager prefs;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = new PrefsManager(this);
        handler = new Handler(Looper.getMainLooper());
        createChannels();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        isRunning = true;
        startForeground(NOTIF_PERSISTENT, buildPersistentNotif());
        checkDayRollover();
        startMonitoring();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        if (handler != null && monitorRunnable != null)
            handler.removeCallbacks(monitorRunnable);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    // ── Monitor Loop ──────────────────────────────────────────────────────────

    private void startMonitoring() {
        monitorRunnable = new Runnable() {
            @Override public void run() {
                checkDayRollover();
                checkAppUsage();
                handler.postDelayed(this, POLL_MS);
            }
        };
        handler.post(monitorRunnable);
    }

    private void checkAppUsage() {
        Map<String, Integer> limits = prefs.loadAppLimits();
        if (limits.isEmpty()) return;

        UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        long startOfDay = getStartOfDay();

        UsageEvents events = usm.queryEvents(startOfDay, now);
        UsageEvents.Event event = new UsageEvents.Event();

        Map<String, Long> foregroundTime = new HashMap<>();
        Map<String, Long> fgStart = new HashMap<>();

        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            String pkg = event.getPackageName();
            if (!limits.containsKey(pkg)) continue;

            if (event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                fgStart.put(pkg, event.getTimeStamp());
            } else if (event.getEventType() == UsageEvents.Event.MOVE_TO_BACKGROUND) {
                Long start = fgStart.get(pkg);
                if (start != null) {
                    foregroundTime.put(pkg,
                        foregroundTime.getOrDefault(pkg, 0L) + (event.getTimeStamp() - start));
                    fgStart.remove(pkg);
                }
            }
        }

        // Add still-open session
        for (Map.Entry<String, Long> e : fgStart.entrySet())
            foregroundTime.put(e.getKey(),
                foregroundTime.getOrDefault(e.getKey(), 0L) + (now - e.getValue()));

        // Check limits
        for (Map.Entry<String, Integer> entry : limits.entrySet()) {
            String pkg = entry.getKey();
            long limitMs = entry.getValue() * 60 * 1000L;
            long usedMs  = foregroundTime.getOrDefault(pkg, 0L);

            if (usedMs >= limitMs && !prefs.isAlerted(pkg)) {
                triggerAlert(pkg, usedMs, limitMs);
            }
        }
    }

    // ── Alert: Sound + Notification + Blocker ────────────────────────────────

    private void triggerAlert(String pkg, long usedMs, long limitMs) {
        prefs.markAlerted(pkg);

        // Decide which sound to play
        // sound_first = fahhhhh (1st ever alert)
        // sound_second = Modi ji bkl (subsequent alerts the same day)
        int alertCount = prefs.getAlertCount(pkg);
        playSound(alertCount == 0 ? R.raw.sound_first : R.raw.sound_second);
        prefs.incrementAlertCount(pkg);

        showAlertNotification(pkg, usedMs, limitMs);
        launchBlocker(pkg, usedMs, limitMs);
    }

    private void playSound(int rawResId) {
        try {
            MediaPlayer mp = MediaPlayer.create(this, rawResId);
            if (mp != null) {
                mp.setOnCompletionListener(MediaPlayer::release);
                mp.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlertNotification(String pkg, long usedMs, long limitMs) {
        String name     = getAppName(pkg);
        long   usedMin  = usedMs  / 60000;
        long   limitMin = limitMs / 60000;

        Intent i = new Intent(this, BlockerActivity.class);
        i.putExtra("package", pkg);
        i.putExtra("appName", name);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        PendingIntent pi = PendingIntent.getActivity(this, pkg.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification n = new NotificationCompat.Builder(this, CHANNEL_ALERT)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("⏰ Time's up! " + name)
                .setContentText("Used " + usedMin + " min / limit " + limitMin + " min")
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText("You've spent " + usedMin + " min on " + name +
                                 ". Limit: " + limitMin + " min. Time for a break! 🛑"))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
                .build();

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIF_ALERT_BASE + Math.abs(pkg.hashCode() % 900), n);
    }

    private void launchBlocker(String pkg, long usedMs, long limitMs) {
        Intent i = new Intent(this, BlockerActivity.class);
        i.putExtra("package", pkg);
        i.putExtra("appName", getAppName(pkg));
        i.putExtra("usedMs", usedMs);
        i.putExtra("limitMs", limitMs);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private String getAppName(String pkg) {
        try {
            return getPackageManager().getApplicationLabel(
                    getPackageManager().getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) { return pkg; }
    }

    private long getStartOfDay() {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.set(java.util.Calendar.HOUR_OF_DAY, 0);
        c.set(java.util.Calendar.MINUTE, 0);
        c.set(java.util.Calendar.SECOND, 0);
        c.set(java.util.Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private void checkDayRollover() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        if (!today.equals(prefs.loadLastDate())) {
            prefs.resetAlerts();
            prefs.saveLastDate(today);
        }
    }

    // ── Notification Channels ─────────────────────────────────────────────────

    private void createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

            NotificationChannel persistent = new NotificationChannel(
                    CHANNEL_PERSISTENT, "AppKiller Monitor", NotificationManager.IMPORTANCE_LOW);
            persistent.setDescription("Background monitoring");
            nm.createNotificationChannel(persistent);

            NotificationChannel alert = new NotificationChannel(
                    CHANNEL_ALERT, "Time Limit Alerts", NotificationManager.IMPORTANCE_HIGH);
            alert.setDescription("Time limit reached alerts");
            alert.enableVibration(true);
            nm.createNotificationChannel(alert);
        }
    }

    private Notification buildPersistentNotif() {
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_PERSISTENT)
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setContentTitle("AppKiller is running")
                .setContentText("Monitoring your app usage")
                .setContentIntent(pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }
}
