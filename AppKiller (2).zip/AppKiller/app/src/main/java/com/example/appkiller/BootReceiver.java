package com.example.appkiller;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Map;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            // Only auto-start if there are saved app limits
            PrefsManager prefs = new PrefsManager(context);
            Map<String, Integer> limits = prefs.loadAppLimits();
            if (!limits.isEmpty()) {
                Intent serviceIntent = new Intent(context, AppMonitorService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
            }
        }
    }
}
