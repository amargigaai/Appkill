package com.example.appkiller;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BlockerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blocker);

        String packageName = getIntent().getStringExtra("package");
        String appName = getIntent().getStringExtra("appName");
        long usedMs = getIntent().getLongExtra("usedMs", 0);
        long limitMs = getIntent().getLongExtra("limitMs", 0);

        // Display info
        TextView titleText = findViewById(R.id.blockerTitle);
        TextView detailText = findViewById(R.id.blockerDetail);
        Button closeBtn = findViewById(R.id.closeBtn);
        Button goHomeBtn = findViewById(R.id.goHomeBtn);

        titleText.setText("⏰ Time's Up!");

        long usedMin = usedMs / 60000;
        long limitMin = limitMs / 60000;
        detailText.setText("You've been using " + appName + " for " + usedMin +
                " minutes.\n\nYour limit was " + limitMin + " minutes.\n\nTime to take a break! 🧘");

        // Force close the target app
        if (packageName != null) {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            am.killBackgroundProcesses(packageName);
        }

        // Go back to home screen
        goHomeBtn.setOnClickListener(v -> {
            goHome();
            finish();
        });

        // Just dismiss this screen
        closeBtn.setOnClickListener(v -> {
            goHome();
            finish();
        });
    }

    private void goHome() {
        Intent homeIntent = new Intent(Intent.ACTION_MAIN);
        homeIntent.addCategory(Intent.CATEGORY_HOME);
        homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(homeIntent);
    }

    @Override
    public void onBackPressed() {
        // Prevent going back to the blocked app
        goHome();
        finish();
    }
}
