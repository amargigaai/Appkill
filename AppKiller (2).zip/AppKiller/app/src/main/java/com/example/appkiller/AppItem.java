package com.example.appkiller;

import android.graphics.drawable.Drawable;

public class AppItem {
    private String appName;
    private String packageName;
    private Drawable icon;
    private boolean isSelected;
    private int timeLimitMinutes; // 0 means not set

    public AppItem(String appName, String packageName, Drawable icon) {
        this.appName = appName;
        this.packageName = packageName;
        this.icon = icon;
        this.isSelected = false;
        this.timeLimitMinutes = 30; // default 30 minutes
    }

    public String getAppName() { return appName; }
    public String getPackageName() { return packageName; }
    public Drawable getIcon() { return icon; }
    public boolean isSelected() { return isSelected; }
    public void setSelected(boolean selected) { isSelected = selected; }
    public int getTimeLimitMinutes() { return timeLimitMinutes; }
    public void setTimeLimitMinutes(int minutes) { timeLimitMinutes = minutes; }
}
