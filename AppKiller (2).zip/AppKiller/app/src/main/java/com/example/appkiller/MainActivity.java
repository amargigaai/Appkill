package com.example.appkiller;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private final List<AppItem> allApps      = new ArrayList<>();
    private final List<AppItem> filteredApps = new ArrayList<>();
    private AppAdapter   adapter;
    private PrefsManager prefsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefsManager = new PrefsManager(this);
        setupRecyclerView();
        setupSearch();
        setupButtons();
        checkAndRequestPermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasUsageStatsPermission()) {
            loadInstalledApps();
            syncServiceUI();
        } else {
            showUsageStatsDialog();
        }
    }

    private void setupRecyclerView() {
        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AppAdapter(this, filteredApps, this::updateDashboard);
        rv.setAdapter(adapter);
    }

    private void setupSearch() {
        EditText search = findViewById(R.id.searchBox);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) { filterApps(s.toString()); }
            public void afterTextChanged(Editable s) {}
        });
    }

    private void setupButtons() {
        findViewById(R.id.saveBtn).setOnClickListener(v -> saveSettings());
        findViewById(R.id.startStopBtn).setOnClickListener(v -> toggleService());

        // Long-press Save button = show debug info
        findViewById(R.id.saveBtn).setOnLongClickListener(v -> {
            showDebugInfo();
            return true;
        });
    }

    // ── Debug: shows all packages found on THIS device ────────────────────────
    private void showDebugInfo() {
        PackageManager pm = getPackageManager();
        StringBuilder sb = new StringBuilder();

        // Method 1: queryIntentActivities
        Intent launchIntent = new Intent(Intent.ACTION_MAIN, null);
        launchIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ri1 = pm.queryIntentActivities(launchIntent, 0);
        sb.append("queryIntentActivities: ").append(ri1.size()).append(" apps\n\n");

        // Method 2: getInstalledApplications all
        List<ApplicationInfo> all = pm.getInstalledApplications(0);
        sb.append("getInstalledApplications: ").append(all.size()).append(" total\n\n");

        // Check specifically for Instagram, WhatsApp, Facebook
        String[] targets = {
            "com.instagram.android",
            "com.whatsapp",
            "com.facebook.katana",
            "com.facebook.lite",
            "com.whatsapp.w4b"
        };
        sb.append("--- Target apps ---\n");
        for (String pkg : targets) {
            try {
                ApplicationInfo info = pm.getApplicationInfo(pkg, 0);
                boolean sys     = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean updated = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
                Intent li = pm.getLaunchIntentForPackage(pkg);
                sb.append(pkg).append("\n")
                  .append("  system=").append(sys)
                  .append(" updated=").append(updated)
                  .append(" launch=").append(li != null).append("\n");
            } catch (Exception e) {
                sb.append(pkg).append(" → NOT INSTALLED\n");
            }
        }

        sb.append("\n--- All launcher apps ---\n");
        for (ResolveInfo ri : ri1) {
            sb.append(ri.activityInfo.packageName).append("\n");
        }

        new AlertDialog.Builder(this)
            .setTitle("Debug Info (" + allApps.size() + " shown)")
            .setMessage(sb.toString())
            .setPositiveButton("OK", null)
            .setNeutralButton("Copy", (d, w) -> {
                android.content.ClipboardManager cm =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(android.content.ClipData.newPlainText("debug", sb.toString()));
                Toast.makeText(this, "Copied!", Toast.LENGTH_SHORT).show();
            })
            .show();
    }

    private void filterApps(String q) {
        filteredApps.clear();
        for (AppItem a : allApps)
            if (a.getAppName().toLowerCase().contains(q.toLowerCase()))
                filteredApps.add(a);
        adapter.notifyDataSetChanged();
    }

    private void saveSettings() {
        Map<String, Integer> limits = new java.util.HashMap<>();
        for (AppItem app : allApps)
            if (app.isSelected())
                limits.put(app.getPackageName(), app.getTimeLimitMinutes());

        if (limits.isEmpty()) {
            Toast.makeText(this, "Select at least one app first!", Toast.LENGTH_SHORT).show();
            return;
        }
        prefsManager.saveAppLimits(limits);
        prefsManager.resetAlerts();
        Toast.makeText(this, "Saved! " + limits.size() + " app(s) monitored.", Toast.LENGTH_SHORT).show();
        updateDashboard();
    }

    private void toggleService() {
        Intent svc = new Intent(this, AppMonitorService.class);
        if (AppMonitorService.isRunning) {
            stopService(svc);
        } else {
            if (prefsManager.loadAppLimits().isEmpty()) {
                Toast.makeText(this, "Save your app selections first!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc);
            else startService(svc);
        }
        syncServiceUI();
    }

    private void syncServiceUI() {
        Button btn     = findViewById(R.id.startStopBtn);
        TextView badge = findViewById(R.id.activeBadge);
        if (AppMonitorService.isRunning) {
            btn.setText("Stop Monitoring");
            badge.setText("● ACTIVE");
            badge.setTextColor(Color.parseColor("#22C55E"));
            badge.setBackgroundResource(R.drawable.badge_active_bg);
        } else {
            btn.setText("Start Monitoring");
            badge.setText("● INACTIVE");
            badge.setTextColor(Color.parseColor("#6B7280"));
            badge.setBackgroundResource(R.drawable.badge_inactive_bg);
        }
    }

    private void updateDashboard() {
        List<AppItem> selected = new ArrayList<>();
        for (AppItem a : allApps) if (a.isSelected()) selected.add(a);

        ((TextView) findViewById(R.id.trackingCount)).setText(String.valueOf(selected.size()));

        LinearLayout chips  = findViewById(R.id.chipsContainer);
        View         scroll = findViewById(R.id.chipsScroll);
        chips.removeAllViews();

        if (!selected.isEmpty()) {
            scroll.setVisibility(View.VISIBLE);
            for (AppItem app : selected) {
                TextView chip = new TextView(this);
                int h = app.getTimeLimitMinutes() / 60;
                int m = app.getTimeLimitMinutes() % 60;
                chip.setText("● " + app.getAppName() + "  •  " + (h > 0 ? h + "h " + m + "m" : m + "m"));
                chip.setTextSize(12f);
                chip.setTextColor(Color.parseColor("#9CA3AF"));
                chip.setBackgroundResource(R.drawable.dashboard_chip_bg);
                chip.setPadding(dp(12), dp(6), dp(12), dp(6));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMarginEnd(dp(8));
                chip.setLayoutParams(lp);
                chips.addView(chip);
            }
        } else {
            scroll.setVisibility(View.GONE);
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ── UNIVERSAL App Loader ──────────────────────────────────────────────────
    // Tries 3 methods and merges results for max compatibility
    private void loadInstalledApps() {
        PackageManager pm    = getPackageManager();
        Map<String, Integer> saved = prefsManager.loadAppLimits();
        allApps.clear();

        Set<String> seen = new HashSet<>();
        List<AppItem> result = new ArrayList<>();

        // ── METHOD 1: queryIntentActivities (best for Samsung, Xiaomi, Realme)
        try {
            Intent li = new Intent(Intent.ACTION_MAIN, null);
            li.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(li, PackageManager.GET_META_DATA);
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || seen.contains(pkg)) continue;
                seen.add(pkg);
                try {
                    AppItem item = new AppItem(
                        ri.loadLabel(pm).toString(), pkg, ri.loadIcon(pm));
                    if (saved.containsKey(pkg)) {
                        item.setSelected(true);
                        item.setTimeLimitMinutes(saved.get(pkg));
                    }
                    result.add(item);
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}

        // ── METHOD 2: getInstalledApplications - catches apps Method 1 misses
        try {
            List<ApplicationInfo> pkgs = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            for (ApplicationInfo info : pkgs) {
                String pkg = info.packageName;
                if (pkg.equals(getPackageName()) || seen.contains(pkg)) continue;

                // Only include if it has a launch intent (is user-facing)
                Intent launch = pm.getLaunchIntentForPackage(pkg);
                if (launch == null) continue;

                seen.add(pkg);
                try {
                    AppItem item = new AppItem(
                        pm.getApplicationLabel(info).toString(),
                        pkg,
                        pm.getApplicationIcon(info));
                    if (saved.containsKey(pkg)) {
                        item.setSelected(true);
                        item.setTimeLimitMinutes(saved.get(pkg));
                    }
                    result.add(item);
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}

        // ── METHOD 3: Force-add known popular apps if installed but still missing
        String[] popularPkgs = {
            "com.instagram.android",
            "com.whatsapp",
            "com.whatsapp.w4b",
            "com.facebook.katana",
            "com.facebook.lite",
            "com.facebook.orca",       // Messenger
            "com.snapchat.android",
            "com.twitter.android",
            "com.linkedin.android",
            "com.zhiliaoapp.musically", // TikTok
            "com.ss.android.ugc.trill", // TikTok alt
            "com.google.android.youtube",
            "com.netflix.mediaclient",
            "com.spotify.music",
            "com.amazon.mShop.android.shopping",
            "com.flipkart.android",
            "com.phonepe.app",
            "net.one97.paytm",
            "in.swiggy.android",
            "app.zomato.restaurants",
            "com.ola.client",
            "com.ubercab",
            "com.mxtech.videoplayer.ad",  // MX Player
            "com.hotstar.android",
            "com.jio.media.jiocinema",
            "com.jio.prime",
            "com.sharechat.android",
            "com.josh.short.video.app",
            "com.meesho.supply",
            "com.myntra.android",
            "com.naukri.android",
        };

        for (String pkg : popularPkgs) {
            if (seen.contains(pkg)) continue;
            try {
                ApplicationInfo info = pm.getApplicationInfo(pkg, 0);
                seen.add(pkg);
                AppItem item = new AppItem(
                    pm.getApplicationLabel(info).toString(),
                    pkg,
                    pm.getApplicationIcon(info));
                if (saved.containsKey(pkg)) {
                    item.setSelected(true);
                    item.setTimeLimitMinutes(saved.get(pkg));
                }
                result.add(item);
            } catch (Exception ignored) {
                // Not installed on this device — skip
            }
        }

        Collections.sort(result, (a, b) ->
                a.getAppName().compareToIgnoreCase(b.getAppName()));

        allApps.addAll(result);
        filteredApps.clear();
        filteredApps.addAll(allApps);
        adapter.notifyDataSetChanged();
        updateDashboard();

        // Show count toast so user knows how many apps were found
        Toast.makeText(this, allApps.size() + " apps found", Toast.LENGTH_SHORT).show();
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    private void checkAndRequestPermissions() {
        if (!hasUsageStatsPermission()) showUsageStatsDialog();
        else onAllPermissionsGranted();
    }

    private boolean hasUsageStatsPermission() {
        try {
            android.app.AppOpsManager ops =
                    (android.app.AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(
                    android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
            return mode == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    private void showUsageStatsDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Permission Required")
                .setMessage("AppKiller needs 'Usage Access' permission.\n\nTap OK to open Settings.")
                .setPositiveButton("Open Settings", (d, w) ->
                        startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)))
                .setNegativeButton("Exit", (d, w) -> finish())
                .setCancelable(false).show();
    }

    private void onAllPermissionsGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);

        if (!Settings.canDrawOverlays(this))
            new AlertDialog.Builder(this)
                    .setTitle("Overlay Permission")
                    .setMessage("Allow 'Display over other apps' to show the time-up screen.")
                    .setPositiveButton("Grant", (d, w) -> startActivity(new Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()))))
                    .setNegativeButton("Skip", null).show();

        loadInstalledApps();
    }
}
