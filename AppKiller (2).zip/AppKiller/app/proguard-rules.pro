# AppKiller ProGuard Rules
-keep class com.example.appkiller.** { *; }
-keepattributes *Annotation*
